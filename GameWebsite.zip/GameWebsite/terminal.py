import mysql.connector

def printMenu():
    print("------------------- GAME LEADERBOARD -------------------")
    print("| 1. Insert your name and score                        |")
    print("| 2. Show all players and scores                       |")
    print("| 3. Exit                                              |")
    print("--------------------------------------------------------")
    menuChoice = input("Enter your choice: ")
    performMenuChoice(menuChoice)

def performMenuChoice(choice):
    if choice == "1":
        insertScore()
    elif choice == "2":
        showAllPlayersAndScores()  # Corrected function name here
    elif choice == "3":
        exit()
    else:
        print("Invalid choice. Please select 1-3.")
        printMenu()

def insertScore():
    name = input("Enter your name: ")
    score = int(input("Enter your score: "))
    saveToDatabase(name, score)
    input("Press Enter to go back to the menu.")
    printMenu()

def showAllPlayersAndScores():
    mydb = mysql.connector.connect(
        host="localhost", 
        user="Sigma",  # Ensure this is correct
        password="jeffthelandshark", 
        database="leaderboard"
    )

    mycursor = mydb.cursor()

    mycursor.execute("SELECT * FROM scores")

    myresult = mycursor.fetchall()

    print("\n------------------- GAME LEADERBOARD -------------------")
    print("| Rank | Name     | Score |")
    print("|-----------------------------|")
    rank = 1
    for row in myresult:
        print(f"| {rank:<4} | {row[1]:<9} | {row[2]:<5} |")
        rank += 1
    print("--------------------------------------------------------")

    mydb.close()

    input("Press Enter to go back to the menu.")  # Wait for the user to press Enter
    printMenu()  # Call printMenu to go back to the main menu


def saveToDatabase(name, score):
    mydb = mysql.connector.connect(
    host="localhost",
    user="Sigma",  # Now using the Sigma user
    password="jeffthelandshark",  # Same password as before
    database="leaderboard"
)


    mycursor = mydb.cursor()

    sql = "INSERT INTO scores (name, score) VALUES (%s, %s)"
    val = (name, score)
    mycursor.execute(sql, val)

    mydb.commit()

    print(f"{mycursor.rowcount} record inserted.")

# Start the program
printMenu()
